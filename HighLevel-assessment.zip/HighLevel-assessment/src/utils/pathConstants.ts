import * as path from 'path';

export const uploadDir = "src/uploads/";

export const downloadDir = path.join(process.cwd(), 'downloads')